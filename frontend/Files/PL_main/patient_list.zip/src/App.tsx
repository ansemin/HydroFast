import React from "react";
import IPhoneSe from "./components/IPhoneSe";

function App() {
  return <IPhoneSe />;
}

export default App;
