export default {
  content: ["./{src/**/,}*.{js,jsx,ts,tsx,html,svelte,vue}"],
  theme: { extend: {} },
  plugins: [],
  mode: "jit",
};
